# CRUD PY MODULE
from pymongo import MongoClient
from bson.objectid import ObjectId
from bson.json_util import dumps

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        
        # Initialize without authentication
        #self.client = MongoClient('mongodb://localhost:46176')
        
        # Initialize with authentication
        self.client = MongoClient('mongodb://%s:%s@localhost:46176/?authMechanism=DEFAULT&authSource=AAC' % (username, password))
        
        # Uses AAC database
        self.database = self.client['AAC']

# C (Create) in CRUD
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # data should be a dictionary
            return True
        else:
            print("Nothing to save, because data parameter is empty")
            return False

# R (Read) in CRUD

    # Reads ALL documents that satisfy the query
    def read_all(self, data):
        cursor = self.database.animals.find(data, {'_id' : False}) # find method returns a cursor that points to the list
        if cursor.count() > 0: # verifies that at least a document has been found
            return cursor
        else: 
            raise Exception("There is no available data with the given parameters")
    
    # Reads one document that satisfies the query
    def read(self, data):
        animal = self.database.animals.find_one(data)
        if animal != None: # verifies that a document has been found
            json_obj = dumps(animal, indent = 4)
            return json_obj # returns a json object
        else:
            print("There is no available data with the given parameters")
            
            
# U (Update) in CRUD

    # Updates all documents that satisfy the query with new data    
    def update_all(self, currData, newData):
        if self.database.animals.find(currData).count() > 0: # verifies that at least a document is found to proceed
            self.database.animals.update_many(currData, {"$set": newData})
            cursor = self.database.animals.find(newData)
            return cursor  # returns a cursor pointing to the list
        else:
            raise Exception("There is no available data with the given parameters to be updated")

    # Updates only one document that satisfies the query with new data
    def update(self, currData, newData):
        if self.database.animals.find(currData).count() > 0: # verifies that at least a document is found to proceed
            self.database.animals.update_one(currData, {"$set": newData})
            json_obj = dumps(self.database.animals.find_one(newData), indent = 4) # changes to json format
            return json_obj # returns json object
        else:
            print("There is no available data with the given parameters to be updated")            
            
            
# D (Delete) in CRUD

    # Deletes all documents that satisfy the query 
    def delete_all(self, data):
        if self.database.animals.find(data).count() > 0: # verifies that at least a document is found to proceed
            self.database.animals.delete_many(data)
            return True # no explicit data to be returned
        else:
            print("There is no available data with the given parameters to be deleted")            

    # Deletes one document that satisfies the query
    def delete(self, data):
        if self.database.animals.find(data).count() > 0: # verifies that at least a document is found to proceed
            self.database.animals.delete_one(data)
            return True # no explicit data to be returned
        else:
            print("There is no available data with the given parameters to be deleted")            
            